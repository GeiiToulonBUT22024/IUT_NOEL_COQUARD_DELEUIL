/*
 * PeakDetector.h
 *
 */

#ifndef ALGORITHMES_PEAKDETECTOR_H_
#define ALGORITHMES_PEAKDETECTOR_H_

void DetectPeak(int NbPeaks, float spectrum[], int spectrumSize, float Out[]);

#endif /* ALGORITHMES_PEAKDETECTOR_H_ */
