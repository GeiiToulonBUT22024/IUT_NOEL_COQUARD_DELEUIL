/*
 * FFT.h
 *
 *  Created on: 20 nov. 2019
 *      Author: sebas
 */

#ifndef ALGORITHMES_FFT_H_
#define ALGORITHMES_FFT_H_

void fft(float *reel, float *imag, int log2n, int sign);

#endif /* ALGORITHMES_FFT_H_ */
